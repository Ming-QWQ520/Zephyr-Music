# Zephyr Music Windows 构建

## 运行要求
- Windows 10/11 x64
- WebView2 Runtime（Windows 11 已内置，Windows 10 可能需要安装）

## 使用方法
1. 解压本压缩包
2. 双击 Zephyr Music.exe 运行
