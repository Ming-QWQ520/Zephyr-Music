=== Zephyr Music v1.0.1 (网易云版) ===

新增功能：
- 网易云音乐登录（二维码扫码）
- 同步用户歌单
- 每日推荐歌曲
- 右键歌曲弹出菜单（播放/下一首播放/加入队列）

使用方法：
1. 确保网易云 NodeJS API 运行在 http://localhost:3100
   （进入 API 目录运行: PORT=3100 node app.js）
2. 运行 "Zephyr Music.exe"
3. 点击侧边栏"网易云"→ 扫码登录 → 选择歌单 → 播放歌曲

技术栈：Tauri 2 + Vue 3 + TypeScript + Rodio (Rust)
源码：https://github.com/Mingyyds1145/Zephyr-Music
协议：AGPL-3.0
