=== Zephyr Music v1.0.0 ===

受 Apple Music 与 Refined Now Playing 启发的桌面音乐播放器。

运行需求：
- Windows 10/11 (x64)
- WebView2 Runtime（Windows 11 自带）

使用方法：
1. 解压本压缩包到任意目录
2. 运行 "Zephyr Music.exe"

技术栈：Tauri 2 + Vue 3 + TypeScript + Rodio (Rust)
源码：https://github.com/Mingyyds1145/Zephyr-Music
